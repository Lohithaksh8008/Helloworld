<html>
    <head>
        <title>JSP</title>
     <style>
         .box {
  left:10%
}
         .box input[type="button"] {
  border: none;
  outline: none;
  color: #fff;
  background-color: #03a9f4;
  padding: 0.625rem 1.25rem;
  cursor: pointer;
  border-radius: 0.312rem;
  font-size: 1rem;
}

.box input[type="button"]:hover {
  background-color: #1cb1f5;
}
body {
  margin: 0;
  padding: 0;
  background: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url('i3.jpg');
  background-size: cover;
  font-family: sans-serif;
}
         

         </style>
    </head>
    <body>
        
        
        
        <center>
            <div class="box">
                <br><br><br>
               <a href="jsp_reg.php"><input type="button" value="Register criminal"></a>
                &nbsp;<br><br><br><br><br><br>
                <input type="button" value="Search Criminal">
                &nbsp;<br><br><br><br><br><br>
                <a href=jsp3up.php><input type="button" value="Update Criminal"></a>
                &nbsp;<br><br><br><br><br><br>
                <a href="lockup.php"><input type="button" value="Criminal Lockup Details"></a>
                &nbsp;<br><br><br><br><br><br>
                <a href="meeting.php"><input type="button" value="Criminal Meeting details"></a>
                &nbsp;
            </div>
        </center>
    </body>
</html>