<?php

session_start();
$error = "Incorrect Username/Password ";

if(isset($_POST["Login"])){
  $servername="localhost";
$username="root";
$password="";
$dbname="plogin";
$conn=mysqli_connect($servername,$username,$password,$dbname);

 if($conn){
     $user=$_POST['user'];
     $pass=$_POST['pass'];
     $query="SELECT * FROM cbilogin WHERE username='$user' && password='$pass'";
     $result=mysqli_query($conn,$query);
    $total= mysqli_num_rows($result);
    // echo $total;
    if($total>0){
        header("location:cbi2nd.html");
      }
    else{
    $_SESSION["error"] = $error;
    header("location: cbilogin.php"); //send user back to the login page.
	}
}
}
?>

