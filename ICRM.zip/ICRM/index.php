<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Face Detection</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <style>
        body, html {
            height: 100%;
        }
        .bg {
            background-image: url("images/bg.jpg");
            height: 100%;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>


</head>
<body class="bg">
    <div class="container">
        <br><br><br>
        <div class="row">
            <div class="col-md-6 offset-md-3" style="margin:auto; background: white; padding: 20px; box-shadow: 10px 10px 5px #888;">            
                <div class="panel-heading">
                    <h1>Face Detection</h1>
                </div>
                <hr>
                <form action="index.php" method="GET" enctype="multipart/form-data">
                    <input type="file" name="image" accept="image/*" class="form-control">
                    <br>
                    <input type="submit" style="border-radius: 0px;" class="btn btn-lg btn-block btn-outline-success" name="submit" value="Detect Face">
                </form>
            </div>
        </div>
    </div>
    
<!-- <?php


?> -->
<?php
include("connection.php");
error_reporting(0);

 $id=$_GET['image'];
//  echo $id;
$query="SELECT * FROM structure WHERE image_source=$id";
echo "matched";
$data=mysqli_query($conn,$query);
$total=mysqli_num_rows($data);
echo $total;
require "FaceDetector.php";


use svay\FaceDetector;


$faceDetect = new FaceDetector();
$faceDetect->faceDetect($_FILES['image']['tmp_name']);
$faceDetect->toJpeg();

if($_GET['submit'])
{
  // echo "entered";
if($total!=0)
{
  
    ?>
    <table boder="1">
       <tr>
       <th>id</th>
            <th>name</th>
            <th>dob</th>
            <th>bloodgroup</th>
            <th>birthplace</th>
            <th>crimetype</th>
            <th>crimedetails</th>
            <th>photo</th>
            <th colspan="2">operations</th>
            
        </tr>
    <?php
    while($result=mysqli_fetch_assoc($data))
    {
        echo"<tr>
        <td>".$result['criminal_id']."</td>
        <td>".$result['name']."</td>
        <td>".$result['dob']."</td>
        <td>".$result['blood_group']."</td>
        <td>".$result['birth_place']."</td>
        <td>".$result['crime_type']."</td>
        <td>".$result['crime_details']."</td>
        <td><img src='".$result['image_source']."' height='100' width='100'</td>
        <td><a href='update1.php?id=$result[id]&name=$result[name]&dob=$result[dob]&bg=$result[blood_group]&bp=$result[birth_place]&crimetype=$result[crime_type]&crimedetails=$result[crime_details]&image=$result[image_source]' class='button'>Edit</a></td>
        <td><a href='#' class='button' >Delete</td>
        </tr>";
    }
    


     
}
else{
  echo "<h1><b>NO RECORDS FOUND!!!<b><h1>";
}
}
?>

    
</body>
</html>