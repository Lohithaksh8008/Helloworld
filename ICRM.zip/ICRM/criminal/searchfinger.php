<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Indian Criminal Records</title>
    <link rel="stylesheet" href="update.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
  </head>
  <body>

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      <label for="check">
        <i class="fas fa-bars" id="sidebar_btn"></i>
      </label>
      <div class="left_area">
        <h3>Indian<span>CriminalRecords</span></h3>
      </div>
      <div class="right_area">
        <a href="#" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
    <a href="policeversion2.html"><i class="fas fa-th"></i><span>Register</span></a>
      <a href="#"><i class="fas fa-desktop"></i><span>Search</span></a>
      
      <a href="#"><i class="fas fa-cogs"></i><span>Update</span></a>
      <a href="#"><i class="fas fa-table"></i><span >View</span></a>
     
      <a href="#"><i class="fas fa-info-circle"></i><span>Meetings</span></a>

      
    </div>
    <!--sidebar end-->
    <!-- <div class='awesomeBG'> -->

    <div class="main">
       <!--search box start-->  
    <!-- <form action="update.php" class="search-box"  method="GET">
      <input type="text" class="text" name="name1" value="" placeholder="Enter Criminal ID">
      <button class="search-btn" type="submit" name="submit">
       <i class="fas fa-search"></i>
      </button>
      
    </form> -->
    
    <div class="wrapper">
    <div class="container">
      <form role="search" method="POST" class="search-form form" action="searchfinger.php">
        <label>
            <span class="screen-reader-text">Search for...</span>
            <input type="file" class="search-field" placeholder="Enter Criminal fingerprint..." value="" name="finger" title="" />
        </label>
        <input type="submit" class="search-submit button" value="submit" name="submit" />
    </form>
    </div>
  </div>



    
    <br>
    <br>
    <br>
    <div class="main-container" id="mo">
      <div class="card" >
      <?php
$servername="localhost";
$username="root";
$password="";
$dbname="plogin";
$conn=mysqli_connect($servername,$username,$password,$dbname);

if($conn)
{
     echo "connected";
}
else
{
    echo "connection failed";
};
error_reporting(0);
 $finger=$_POST['finger'];

 $md5image = md5(file_get_contents($finger));
$query1="SELECT * FROM structure WHERE encoded_fp LIKE '$md5image'";
$data=mysqli_query($conn,$query1);
$total=mysqli_num_rows($data);

if($_POST['submit'])
{
  // echo "entered";
if($total!=0)
{
  
    ?>
    <table boder="1">
       <tr>
       <th>id</th>
            <th>name</th>
            <th>dob</th>
            <th>bloodgroup</th>
            <th>birthplace</th>
            <th>crimetype</th>
            <th>crimedetails</th>
            <th>photo</th>
            <th>fingerprint</th>
            
            
        </tr>
    <?php
    while($result=mysqli_fetch_assoc($data))
    {
        echo"<tr>
        <td>".$result['criminal_id']."</td>
        <td>".$result['name']."</td>
        <td>".$result['dob']."</td>
        <td>".$result['blood_group']."</td>
        <td>".$result['birth_place']."</td>
        <td>".$result['crime_type']."</td>
        <td>".$result['crime_details']."</td>
        <td><img src='".$result['image_source']."' height='100' width='100'</td>
        <td><img src='".$result['fingerprint']."' height='100' width='100'</td>
        <td><a href='update1.php?id=$result[id]&name=$result[name]&dob=$result[dob]&bg=$result[blood_group]&bp=$result[birth_place]&crimetype=$result[crime_type]&crimedetails=$result[crime_details]&image=$result[image_source]&finger=$result[fingerprint]'</td>
        
        </tr>";
    }
    


     
}
else{
  echo "<h1><b>NO RECORDS FOUND!!!<b><h1>";
}
}
?>
    </div>
    </div>
      
      
 
  <script type="text/javascript">
      $(document).ready(function(){
          $("#sidebar_btn").click(function(){
              $(".sidebar").toggleClass("collapse");
          });
      });
      </script>

  </body>
</html>


































































































<!---->
