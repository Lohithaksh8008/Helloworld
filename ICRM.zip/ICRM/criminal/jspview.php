<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>INDIAN CRIMINAL RECORDS</title>
        <link rel="stylesheet" href="policev1.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
    </head>
    <body>

        <!--wrapper start-->
        <div class="wrapper">
            <!--header menu start-->
            <div class="header">
                <div class="header-menu">
                    <div class="title">SMART<span>CRIMINALTRACKER</span></div>
                    <div class="sidebar-btn">
                        <i class="fas fa-bars"></i>
                    </div>
                    <ul>
                        
                        <li><a href="#"><i class="fas fa-power-off"></i></a></li>
                    </ul>
                </div>
            </div>
            <!--header menu end-->
            <!--sidebar start-->
            <div class="sidebar">
                <div class="sidebar-menu">
                    
                <li class="item">
                    <a href="\ICRM\criminal\jspform.php" class="menu-btn">
                        <i class="fas fa-th"></i><span>Register</span>
                    </a>
                </li>
                <li class="item">
                  <a href="\ICRM\criminal\jspupdate.php" class="menu-btn">
                      <i class="fas fa-cogs"></i><span>Update</span>
                  </a>
              
              </li>
                    
                    <li class="item">
                        <a href="\ICRM\criminal\jspview.php" class="menu-btn">
                            <i class="fas fa-desktop"></i><span>View</span>
                        </a>
                    
                    </li>
                    <li class="item">
                      <a href="\ICRM\criminal\meetings.php" class="menu-btn">
                          <i class="fas fa-info-circle"></i><span>Meetings</span>
                      </a>
                  
                  </li>
                    
                </div>
            </div>
            <!--sidebar end-->
            <!--main container start-->
            
            <div class="main-container">
                 <div class="card">
                 <?php
                 error_reporting(0);

if($_GET['submit'])

$servername="localhost";
$username="root";
$password="";
$dbname="plogin";
$conn=mysqli_connect($servername,$username,$password,$dbname);

if($conn)
{
     echo "connected";
}
else
{
    echo "connection failed";
}

$query="SELECT * FROM structure";
$data=mysqli_query($conn,$query);
$total=mysqli_num_rows($data);
// echo $total;
{
if($total!=0)
{
    ?>
    <table boder="1">
       <tr>
       <th>id</id>
            <th>name</th>
            <th>dob</th>
            <th>bloodgroup</th>
            <th>birthplace</th>
            <th>crimetype</th>
            <th>crimedetails</th>
            <th>photo</th>
            <th>fingerprint<th>
        </tr>
    <?php
    while($result=mysqli_fetch_assoc($data))
    {
     
      // echo $var;
        echo"<tr>
        <td>".$result['criminal_id']."</td>
        <td>".$result['name']."</td>
        <td>".$result['dob']."</td>
        <td>".$result['blood_group']."</td>
        <td>".$result['birth_place']."</td>
        <td>".$result['crime_type']."</td>
        <td>".$result['crime_details']."</td>
        <td><img src='".$result['image_source']."' height='100' width='100'</td>
        <td><img src='".$result['fingerprint']."' height='100' width='100'</td>

        

        </tr>";
    }
    


     
}
}
?>
                    
                </div>
                
            </div> 
            <!--main container end-->
        </div>
        <!--wrapper end-->

        <script type="text/javascript">
        $(document).ready(function(){
            $(".sidebar-btn").click(function(){
                $(".wrapper").toggleClass("collapse");
            });
        });
        </script>

    </body>
</html>
                           