<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Indian Criminal Records</title>
    <link rel="stylesheet" href="jspformre.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <style>
	.errormsg{
		color:red;
		font-size: 15px;
	}
	</style>
	<script>
	function allval()
	{
			nameval();
		dateval();
		placeval();
		crimeval();
		picval();
    fingerval();
		bloodval();
	}
	function formval()
	{
		
		if(document.getElementById("namech").innerHTML==" " &&
document.getElementById("datech").innerHTML==" " &&
document.getElementById("placech").innerHTML==" " &&
document.getElementById("crimech").innerHTML==" " &&
document.getElementById("picch").innerHTML==" " &&
document.getElementById("picch1").innerHTML==" " &&
document.getElementById("bloodch").innerHTML==" ")
{
document.getElementById("sub").disabled=false;
}
else
{
	document.getElementById("sub").disabled=true;
}
	}
	function nameval()
 {
 name=document.crim.NAME.value;
 y=/^[A-Za-z\s]*$/;
 if(name=="" || !(y.test(name)))
 {
document.getElementById("namech").innerHTML="Enter a valid Name";
return false;
}
else
{
document.getElementById("namech").innerHTML=" ";
formval();
return true;
}
}

function placeval()
 {
 name=document.crim.bplace.value;
 y=/^[A-Za-z\s]*$/;
 if(name=="" || !(y.test(name)))
 {
document.getElementById("placech").innerHTML="Enter a valid Birth place";
return false;
}
else
{
document.getElementById("placech").innerHTML=" ";
formval();
return true;
}
}

function crimeval()
 {
 name=document.crim.ctype.value;
 y=/^[A-Za-z\s]*$/;
 if(name=="" || !(y.test(name)))
 {
document.getElementById("crimech").innerHTML="Enter a valid Crime Type";
return false;
}
else
{
document.getElementById("crimech").innerHTML=" ";
formval();
return true;
}
}

function bloodval()
 {
 name=document.crim.blood.value;
 if(name=="O+" ||name=="O-" ||name=="A+" ||name=="A-" ||name=="B+" ||name=="B-" ||name=="AB+" ||name=="AB-")
 {
	document.getElementById("bloodch").innerHTML=" ";
	formval();
	return true;
}
else
{
	document.getElementById("bloodch").innerHTML="Enter a valid Blood Group";
	return false;
}
}	

 function picval() { 
            var fileInput =  
                document.getElementById('pic'); 
              
            var filePath = fileInput.value; 
          
            // Allowing file type 
            var allowedExtensions =  
                    /(\.jpg|\.jpeg|\.png)$/i; 
              
            if (!allowedExtensions.exec(filePath)) { 
                document.getElementById("picch").innerHTML="Invalid File type"; 
                fileInput.value = ''; 
                return false; 
            }  
            else  
            { 
				document.getElementById("picch").innerHTML=" "; 
				formval();
				return true;
                
            } 
        } 
        function fingerval() { 
            var fileInput =  
                document.getElementById('pic1'); 
              
            var filePath = fileInput.value; 
          
            // Allowing file type 
            var allowedExtensions =  
                    /(\.jpg|\.jpeg|\.png)$/i; 
              
            if (!allowedExtensions.exec(filePath)) { 
                document.getElementById("picch1").innerHTML="Invalid File type"; 
                fileInput.value = ''; 
                return false; 
            }  
            else  
            { 
				document.getElementById("picch1").innerHTML=" "; 
				formval();
				return true;
                
            } 
        } 
		
		function dateval()
		{
			 dt=document.crim.dob.value;
			 var date = new Date(dt);
			 document.getElementById("datech").innerHTML=date;

if(date.getFullYear() > 2002) 
  {
			 document.getElementById("datech").innerHTML="Criminal must be above 18 years"; 
			 document.getElementById("sub").disabled=true;
			 return false;
		}
		else{
			document.getElementById("datech").innerHTML=" ";
			formval();
			return true;
		}
	}
	</script>
  </head>
  <body>

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      <label for="check">
        <i class="fas fa-bars" id="sidebar_btn"></i>
      </label>
      <div class="left_area">
        <h3>Indian<span>CriminalRecords</span></h3>
      </div>
      <div class="right_area">
        <a href="index1.html" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      
    <a href="#"><i class="fas fa-th"></i><span>Register</span></a>
      <!-- <a href="search.html"><i class="fas fa-desktop"></i><span>Search</span></a> -->
      <a href="#"><i class="fas fa-cogs"></i><span>Update</span></a>
      <a href="#"><i class="fas fa-table"></i><span >View</span></a>
     
      <a href="#"><i class="fas fa-info-circle"></i><span>Meetings</span></a>
      
    </div>
    <!--sidebar end-->
    <div class='awesomeBG'>

    <div class="main">
      
      <div class="grid-container" id="mo">
        <div class="grid-item" >
      <div class="form">
        <p>Criminal Registration Form</p>
        <form action="update2nd.php" method="POST" name ="crim" enctype="multipart/form-data">
        <input type="text" name="id" placeholder="Criminal id" value="<?php echo $_GET['id'];?>"required/>
        <input type="text" name="NAME" placeholder="Criminal Name" onfocusout="nameval()" value="<?php echo $_GET['name'];?>" required><div id="namech" class="errormsg"></div>
            <input type="date" required name="dob" placeholder="dob" onchange="dateval()" value="<?php echo $_GET['dob'];?>" required><div id="datech" class="errormsg"></div>
            <input type="text" name="blood" placeholder="Blood group" onfocusout="bloodval()" value="<?php echo $_GET['bg'];?>" required><div id="bloodch" class="errormsg"></div>
            <input type="text" name="bplace" placeholder="Birth Place" onfocusout="placeval()" value="<?php echo $_GET['bp'];?>" required><div id="placech" class="errormsg"></div>
            <input type="text" name="ctype" placeholder="Crime type" onfocusout="crimeval()" value="<?php echo $_GET['crimetype'];?>" required><div id="crimech" class="errormsg"></div>
            <!-- <input type="textarea" name="cdetails" placeholder="Crime details"> -->
            <textarea name="tarea" required placeholder="Crime details" rows="5" required><?php echo $_GET['crimedetails'];?></textarea>
            <h6>Upload an image</h6>
            <input type="file" id="pic" name="uploadfile" value="" onchange="allval(),formval()"><?php echo   $_GET['image']; ?><div id="picch" class="errormsg" required></div>
            <h6>Upload a fingerprint</h6>
            <input type="file" id="pic1" name="uploadfile1" value="" onchange="allval(),formval()"><?php echo   $_GET['finger']; ?><div id="picch1" class="errormsg" required></div>
            <input type="submit" disabled="disabled" name="submit" id="sub">
            
        </form>
      </div>
    </div>
  </div>
  </div>

  </div>
  
  </body>
  </html>
    <?php

     if(isset($_POST["submit"])){
    echo "working";
    $connection=mysqli_connect("localhost","root","","plogin");
  
    if($connection){
        echo "connected";
        $id=$_POST['id'];
        $name=$_POST["NAME"];
        $dob=$_POST["dob"];
        $bg=$_POST["blood"];
        $bp=$_POST["bplace"];
        $crimetype=$_POST["ctype"];
        $crimedetails=$_POST["tarea"];
        $filename=$_FILES["uploadfile"]["name"];
        $tempname=$_FILES["uploadfile"]["tmp_name"];
        $folder='D:/xampp/htdocs/ST/criminal/'.$filename;
        move_uploaded_file($tempname,$folder);
        $filename1=$_FILES["uploadfile1"]["name"];
        $tempname1=$_FILES["uploadfile1"]["tmp_name"];
        $folder1='D:/xampp/htdocs/ST/criminal/'.$filename1;
        move_uploaded_file($tempname1,$folder1);
        $md5image1 = md5(file_get_contents($filename));
        $md5image2 = md5(file_get_contents($filename1));
   
    $query="UPDATE structure SET name='$name', dob='$dob' , blood_group='$bg', birth_place='$bp', crime_type='$crimetype', crime_details='$crimedetails' ,image_source='$filename' ,encoded_image='$md5image1' ,fingerprint='$filename1',encoded_fp='$md5image2' WHERE criminal_id='$id'";
    $data=mysqli_query($connection,$query);
    if($data)
    { 
      header("location:jsp2nd.html");
    }
    else{
        echo "record not updated";
    }

  }
}
  else
  {
    echo "click on update button to save changes";
  }

  ?>


