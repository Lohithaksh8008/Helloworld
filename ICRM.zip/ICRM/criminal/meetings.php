<?php
error_reporting(0);
if(isset($_POST["submit"])){
    echo "working";
    $connection=mysqli_connect("localhost","root","","plogin");
    if($connection){
        // echo "connected";
        $id=$_POST["id"];
        $name=$_POST["NAME"];
        $visitor=$_POST["visitor"];
        $date=$_POST["visitingd"];
        $intime=$_POST["time"];
        $outtime=$_POST["time1"];
        
      
        $query="INSERT INTO meetings(criminal_id,criminal_name,visitor_name,date,in_time,out_time)values('$id','$name','$visitor','$date','$intime','$outtime')";
        mysqli_query($connection,$query);
    }
}
?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Indian Criminal Records</title>
    <link rel="stylesheet" href="jspformre.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
  </head>
  <body>

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      <label for="check">
        <i class="fas fa-bars" id="sidebar_btn"></i>
      </label>
      <div class="left_area">
        <h3>SMART<span>CRIMINALTRACKER</span></h3>
      </div>
      <div class="right_area">
        <a href="ICRM/index1.html" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      
    <a href="\ICRM\criminal\jspform.php"><i class="fas fa-th"></i><span>Register</span></a>
      <!-- <a href="search.html"><i class="fas fa-desktop"></i><span>Search</span></a> -->
      <a href="\ICRM\criminal\jspupdate.php"><i class="fas fa-cogs"></i><span>Update</span></a>
      <a href="\ICRM\criminal\jspview.php"><i class="fas fa-table"></i><span >View</span></a>
     
      <a href="\ICRM\criminal\meetings.php"><i class="fas fa-info-circle"></i><span>Meetings</span></a>
      
    </div>
    <!--sidebar end-->
    <div class='awesomeBG'>

    <div class="main">
      
      <div class="grid-container" id="mo">
        <div class="grid-item" >
      <div class="form">
        <p>Criminal meetings Form</p>
        <form action="meetings.php" method="POST" enctype="multipart/form-data">
        <input type="text" name="id" placeholder="Criminal id" required>
            <input type="text" name="NAME" placeholder="Criminal Name" required>
            
            <input type="text" name="visitor" placeholder="Visitor's name" required>
           
             <input type="date" name="visitingd" placeholder="Visiting date" required>
             <h6>IN TIME</h6>
             <input type="time" id="appt" name="time"  placeholder="In time" min="09:00"  max="18:00" required>
             <h6>OUT TIME</h6>
             <input type="time" id="appt" name="time1"  placeholder="Out time" min="09:00" max="18:00" required>
            
            <input type="submit" name="submit">
            
        </form>
      </div>
    </div>
  </div>
  </div>

  </div>

  </body>
</html>


































































































<!---->
