<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Indian Criminal Records</title>
    <link rel="stylesheet" href="view.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
  </head>
  <body>

    <input type="checkbox" id="check">
    <!--header area start-->
    <header>
      <label for="check">
        <i class="fas fa-bars" id="sidebar_btn"></i>
      </label>
      <div class="left_area">
        <h3>Indian<span>CriminalRecords</span></h3>
      </div>
      <div class="right_area">
        <a href="#" class="logout_btn">Logout</a>
      </div>
    </header>
    <!--header area end-->
    <!--sidebar start-->
    <div class="sidebar">
      
      <!-- <a href="#"><i class="fas fa-desktop"></i><span>Search</span></a> -->
        <a href="policeversion2.html"><i class="fas fa-th"></i><span>Register</span></a>
      <a href="#"><i class="fas fa-cogs"></i><span>Update</span></a>
      <a href="#"><i class="fas fa-table"></i><span >View</span></a>
    
      <a href="#"><i class="fas fa-info-circle"></i><span>Meetings</span></a>
      
    </div>
    <!--sidebar end-->
    <!-- <div class='awesomeBG'> -->

    <div class="main">
    <form action=view.php method="GET">
    <input type="submit" name="submit" value="View All Criminals" onclick="validate()">
</form>
    
     

    <br>
    <br>
    <br>
    <div class="grid-container" id="mo">
      <div class="grid-item" >
      <?php

if($_GET['submit'])

$servername="localhost";
$username="root";
$password="";
$dbname="plogin";
$conn=mysqli_connect($servername,$username,$password,$dbname);

if($conn)
{
     echo "connected";
}
else
{
    echo "connection failed";
}
error_reporting(0);
$query="SELECT * FROM structure";
$data=mysqli_query($conn,$query);
$total=mysqli_num_rows($data);
// echo $total;
{
if($total!=0)
{
    ?>
    <table boder="1">
       <tr>
       <th>id</id>
            <th>name</th>
            <th>dob</th>
            <th>bloodgroup</th>
            <th>birthplace</th>
            <th>crimetype</th>
            <th>crimedetails</th>
            <th>photo</th>
            <th>fingerprint<th>
        </tr>
    <?php
    while($result=mysqli_fetch_assoc($data))
    {
     
      // echo $var;
        echo"<tr>
        <td>".$result['criminal_id']."</td>
        <td>".$result['name']."</td>
        <td>".$result['dob']."</td>
        <td>".$result['blood_group']."</td>
        <td>".$result['birth_place']."</td>
        <td>".$result['crime_type']."</td>
        <td>".$result['crime_details']."</td>
        <td><img src='".$result['image_source']."' height='100' width='100'</td>
        <td><img src='".$result['fingerprint']."' height='100' width='100'</td>

        

        </tr>";
    }
    


     
}
}
?>

    </div>
    </div>
      
      
  </div>

  </div>

  </body>
</html>


































































































<!---->
