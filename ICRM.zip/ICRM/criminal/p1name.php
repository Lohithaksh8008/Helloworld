<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>UPDATE RECORDS</title>
        <link rel="stylesheet" href="jspupdate.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
    </head>
    <body>

        <!--wrapper start-->
        <div class="wrapper">
            <!--header menu start-->
            <div class="header">
                <div class="header-menu">
                    <div class="title">SMART<span>CRIMINALTRACKER</span></div>
                    <div class="sidebar-btn">
                        <i class="fas fa-bars"></i>
                    </div>
                    <ul>
                        
                        <li><a href="#"><i class="fas fa-power-off"></i></a></li>
                    </ul>
                </div>
            </div>
            <!--header menu end-->
            <!--sidebar start-->
            <div class="sidebar">
                <div class="sidebar-menu">

                  <!-- <li class="item">
                    <a href="\ICRM\criminal\jspform.php" class="menu-btn">
                        <i class="fas fa-th"></i><span>Register</span>
                    </a>
                </li>
                <li class="item">
                  <a href="\ICRM\criminal\jspupdate.php" class="menu-btn">
                      <i class="fas fa-cogs"></i><span>Update</span>
                  </a>
              
              </li> -->
                    
                    <li class="item">
                        <a href="\ICRM\criminal\viewp1.php" class="menu-btn">
                            <i class="fas fa-desktop"></i><span>View</span>
                        </a>
                    
                    </li>
                    <li class="item" id="profile">
                        <a href="#profile" class="menu-btn">
                            <i class="fas fa-user-circle"></i><span>Search <i class="fas fa-chevron-down drop-down"></i></span>
                        </a>
                        <div class="sub-menu">
                            <a href="\ICRM\criminal\p1id.php"><i class="fas fa-image"></i><span>ID</span></a>
                            <a href="\ICRM\criminal\p1name.php"><i class="fas fa-image"></i><span>Name</span></a>
                            <a href="\ICRM\criminal\p1blood.php"><i class="fas fa-image"></i><span>Blood Group</span></a>
                            <a href="\ICRM\criminal\p1crime.php"><i class="fas fa-image"></i><span>Crime Type</span></a>
                            <a href="\ICRM\criminal\searchfinger1.php"><i class="fas fa-image"></i><span>Finger print</span></a>
                            <a href="#"><i class="fas fa-address-card"></i><span>Image Matching</span></a>
                        </div>
                    </li>
                    <!-- <li class="item">
                      <a href="\ICRM\criminal\meetings.php" class="menu-btn">
                          <i class="fas fa-info-circle"></i><span>Meetings</span>
                      </a>
                  
                  </li> -->
                    
                </div>
            </div>
            <!--sidebar end-->
            <!--main container start-->
            <div class="main-container">
                <div class="wrapper1">
                    <div class="container">
                      <form role="search" method="GET" class="search-form form" action="p1name.php">
                        <label>
                            <span class="screen-reader-text">Search for...</span>
                            <input type="search" class="search-field" placeholder="Enter Criminal Name..." value="" name="name1" title="" />
                        </label>
                        <input type="submit" class="search-submit button" value="submit" name="submit" />
                    </form>
                    </div>
                  </div>
                 <div class="card">
                    <?php
                    $servername="localhost";
                    $username="root";
                    $password="";
                    $dbname="plogin";
                    $conn=mysqli_connect($servername,$username,$password,$dbname);
                    
                    if($conn)
                    {
                         echo "connected";
                    }
                    else
                    {
                        echo "connection failed";
                    };
                   error_reporting(0);
                     $blood=$_GET['name1'];
                    $query="SELECT * FROM structure WHERE name = '$blood'";
                    $data=mysqli_query($conn,$query);
                    $total=mysqli_num_rows($data);
                    echo $total;
                    if($_GET['submit'])
                    {
                       echo "entered";
                    
                    if($total!=0)
                    {
                      echo "Hello";
                        echo $total;
                        ?>
                        <table boder="1">
                           <tr>
                           <th>id</th>
                                <th>name</th>
                                <th>dob</th>
                                <th>bloodgroup</th>
                                <th>birthplace</th>
                                <th>crimetype</th>
                                <th>crimedetails</th>
                                <th>photo</th>
                                <th>fingerprint</th>
                               
                                
                            </tr>
                        <?php
                        while($result=mysqli_fetch_assoc($data))
                        {
                            echo"<tr>
                            <td>".$result['criminal_id']."</td>
                            <td>".$result['name']."</td>
                            <td>".$result['dob']."</td>
                            <td>".$result['blood_group']."</td>
                            <td>".$result['birth_place']."</td>
                            <td>".$result['crime_type']."</td>
                            <td>".$result['crime_details']."</td>
                            <td><img src='".$result['image_source']."' height='100' width='100'</td>
                            <td><img src='".$result['fingerprint']."' height='100' width='100'</td>
                            <td><a href='update2nd.php?id=$result[criminal_id]&name=$result[name]&dob=$result[dob]&bg=$result[blood_group]&bp=$result[birth_place]&crimetype=$result[crime_type]&crimedetails=$result[crime_details]&image=$result[image_source]d_group]&bp=$result[birth_place]&crimetype=$result[crime_type]&crimedetails=$result[crime_details]&image=$result[image_source]&finger=$result[fingerprint]'</td>       
                            
                            </tr>";
                        }
                        
                    
                    
                         
                    }
                    else{
                      echo "<h1><b>NO RECORDS FOUND!!!<b><h1>";
                    }
                    }
                    ?>
                </div>
                <!-- <div class="card">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                </div>
                <div class="card">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                </div> -->
            </div> 
            <!--main container end-->
        </div>
        <!--wrapper end-->

        <script type="text/javascript">
        $(document).ready(function(){
            $(".sidebar-btn").click(function(){
                $(".wrapper").toggleClass("collapse");
            });
        });
        </script>

    </body>
</html>
                           